package main;

import database.DatabaseContext;
import domain.CheckoutItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@WebServlet(urlPatterns = {"/checkout"})
public class CheckoutServlet extends HttpServlet {
    DatabaseContext db;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var products = db.getProducts();
        var cart = (HashMap<Integer, Integer>) req.getSession().getAttribute("cart");
        var checkOutItems = new ArrayList<CheckoutItem>();
        if(cart != null){
        for(var item : cart.entrySet()){
            var product = products.stream().filter(x-> x.getId() == item.getKey()).findFirst().orElse(null);
            checkOutItems.add(new CheckoutItem(product, item.getValue()));
        }}
        req.setAttribute("items", checkOutItems);
        req.getRequestDispatcher("WEB-INF/views/checkout.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }

    @Override
    public void init() throws ServletException {
        super.init();
        db = new DatabaseContext();
    }
}
