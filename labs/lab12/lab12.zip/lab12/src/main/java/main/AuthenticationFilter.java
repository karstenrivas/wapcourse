package main;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebFilter(urlPatterns = {"/xxx*"})
public class AuthenticationFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String servletName = req.getServletPath();
        if(!servletName.equals("/login") && !servletName.equals("/logout") && req.getSession(false) == null){
            ((HttpServletResponse) response).sendRedirect("login");
        }else{
            chain.doFilter(request, response);
        }


    }

    @Override
    public void destroy() {

    }
}
