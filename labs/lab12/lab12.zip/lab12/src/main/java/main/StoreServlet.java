package main;

import database.DatabaseContext;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet(urlPatterns = {"/store" , "/"})
public class StoreServlet  extends HttpServlet {

    DatabaseContext db;
    @Override
    public void init() throws ServletException {
        super.init();
        db = new DatabaseContext();

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        var q =req.getParameter("q");
        req.setAttribute("Items", db.getProducts(q));
        req.getRequestDispatcher("WEB-INF/views/store.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
