package domain;

public class Product {

    private Integer id;
    private String name;

    private String imageUrl;
    private Double price;
    private int stock;

    public Product(Integer id, String name, String imageUrl, Double price, int stock) {
        this.id = id;
        this.name = name;

        this.imageUrl = imageUrl;
        this.price = price;
        this.stock = stock;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }


    public String getImageUrl() {
        return imageUrl;
    }

    public Double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }
}
