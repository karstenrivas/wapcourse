package database;

import domain.Product;
import domain.User;

import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class DatabaseContext {
    HashMap<String, User> users;
    HashMap<Integer, Product> products;

    public DatabaseContext() {
        createUsers();
        createProducts();
    }


    private void createUsers() {
        users = new HashMap<String, User>();
        var user1 = new User("Karsten", "12345");
        var user2 = new User("Rakesh", "67890");
        users.put(user1.getUserName(), user1);
        users.put(user2.getUserName(), user2);
    }
    private void createProducts() {
        products = new HashMap<Integer, Product>();
        var product1 = new Product(1,"laptop 360", "img/laptop.png",400.49, 10);
        var product2 = new Product(2,"camera pro", "img/camera.jpg",650.99, 20);
        var product3 = new Product(3,"keyboard", "img/keyboard.png",33.99, 30);
        var product4 = new Product(4,"laptop surface", "img/laptop.png",550.99, 10);
        var product5 = new Product(5,"camera xpro", "img/camera.jpg",750.99, 20);
        var product6 = new Product(6,"keyboard", "img/keyboard.png",35.99, 30);

        products.put(product1.getId(), product1);
        products.put(product2.getId(), product2);
        products.put(product3.getId(), product3);
        products.put(product4.getId(), product4);
        products.put(product5.getId(), product5);
        products.put(product6.getId(), product6);
    }

    public User getUser(String username) {
        return users.get(username);
    }
    public List<Product> getProducts() {
        return getProducts("");
    }
    public List<Product> getProducts(String q) {
        if(q== null)
            q ="";
        String filter = q;
        return products.entrySet().stream().map(x-> x.getValue()).filter(x-> x.getName().contains(filter)).collect(Collectors.toList());
    }

}