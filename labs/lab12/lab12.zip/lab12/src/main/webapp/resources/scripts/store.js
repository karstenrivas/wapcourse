window.onload = function(){
    document.querySelectorAll(".addToCart").forEach(e=> e.addEventListener("click",
        async (evt)=>{
        let id = evt.target.dataset.id;
            let _data = {
                id:id, quantity:1
            }
            document.getElementById('loading').style.display = 'block';
        await fetch("addToCart", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json; charset=UTF-8'
            },
            body: JSON.stringify(_data)
        }).then(res => res.json())
            .then(data => {
            let label = document.getElementById("cartItemsQuantity");
            label.innerText = `(${data})`
                setTimeout(()=>document.getElementById('loading').style.display = 'none', 500)
            });
        evt.target.blur()
    }))
}