package main;

import database.UserDatabase;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/login"}, name = "LoginServlet")
public class LoginServlet extends HttpServlet {

    UserDatabase db;
    final String rememberMeCookieName = "username";
    final String promoCookieName = "promo";
    @Override
    public void init() throws ServletException {
        super.init();
        db = new UserDatabase();
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Lab 11</title></head><body>");
        out.print("<form method='post'>");
        var c = findCookie(req, rememberMeCookieName);
        var username = c == null? "": c.getValue();
        out.print("Username:<br /> <input type='text' name='username' value='"+username +"'/> <br />");
        out.print("Password:<br /> <input type='password' name='password'/> <br />");
        if(req.getAttribute("loginStatus") != null && !Boolean.parseBoolean(req.getAttribute("loginStatus").toString()))
            out.print("<p style='color:red '>Invalid credentials</p>");
        out.print("<input type='checkbox' name='remember' /> Remember me <br/>");
        out.print("<input type='submit' value='Login'/> ");
        out.print("</form>");
        out.print("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       var userName = req.getParameter("username");
       var password = req.getParameter("password");
       var remember = req.getParameter("remember");
       var user = db.getUser(userName);
       if(user != null && user.getPassword().equals(password)){
          var session = req.getSession();
          session.setAttribute("username", userName);
           Cookie rememberMeCookie, promoCookie;
           if(remember!= null && remember.equals("on")){
               rememberMeCookie = new Cookie(rememberMeCookieName, userName);
              rememberMeCookie.setMaxAge(3600 *24 *30);
           }else{
               rememberMeCookie = findCookie(req, rememberMeCookieName);
              if(rememberMeCookie != null)
              rememberMeCookie.setMaxAge(0);
           }
           promoCookie = new Cookie(promoCookieName, "100$");
           promoCookie.setMaxAge(3600 *24 *30);
           if(rememberMeCookie!= null)
           resp.addCookie(rememberMeCookie);
           resp.addCookie(promoCookie);
           resp.sendRedirect("welcome");
       }else{
           req.setAttribute("loginStatus", false);
           doGet(req,resp);
       }

    }

    private Cookie findCookie(HttpServletRequest req, String name){
        for(Cookie c :  req.getCookies()){
            if(c!= null && c.getName().equals(name))
                return c;
        }
        return null;
    }


}
