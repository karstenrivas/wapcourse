package database;

import domain.User;

import java.util.*;

public class UserDatabase {
    HashMap<String, User> users;

    public UserDatabase(){
        users = new HashMap<String, User>();
        var user1 = new User("Karsten", "12345");
        var user2 = new User("Rakes", "67890");
        users.put(user1.getUserName(), user1);
        users.put(user2.getUserName(), user2);
        }

        public User getUser(String username){
        return users.get(username);
        }
    }

