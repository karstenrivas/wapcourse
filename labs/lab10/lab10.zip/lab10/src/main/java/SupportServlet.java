
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

@WebServlet("/support")
public class SupportServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Test</title></head><body>");
        out.print("<form method='post'>");
        out.print("Name:<br /> <input type='text' name='name'/> <br />");
        out.print("Email Address:<br /> <input type='text' name='email'/> <br />");
        out.print("Problem:<br /> <input type='text' name='problem'/> <br />");
        out.print("Problem Description: <br /><textarea name='description'></textarea> <br />");
        out.print("<input type='submit' value='Send'/> ");
        out.print("</form>");
        out.print("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.print("<html><head><title>Test</title></head><body>");
        var name = req.getParameter("name");
        var email = req.getParameter("email");
        var supportEmail = getServletContext().getInitParameter("support-email");
        var support_ticket_id = new Random().nextInt(10000000);

        out.print("<p>Thank you! " + name + " for contacting us. We should receive reply from us with in 24 hrs in\n" +
                "your email address " +email +". Let us know in our support email "+ supportEmail + " if\n" +
                "you do not receive reply within 24 hrs. Please be sure to attach your reference\n" +
                support_ticket_id + " in your email. </p>");

        out.print("</body></html>");
    }
}
